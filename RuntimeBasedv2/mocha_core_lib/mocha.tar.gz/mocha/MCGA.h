//Genetic Algorithm

//1. solutionSelector
//2. mutationGenerator
//3. crossoverOperator
//4. fitnessCalculator

