#include "MCContext.h"

#ifndef _MCMath 
#define _MCMath _MCObject;\
	unsigned tid;\

class(MCMath);
constructor(MCMath, xxx);

method(MCMath, new, xxx);

#endif