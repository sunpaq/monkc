/*
 * BirdFather.c
 *
 *  Created on: 2014��2��15��
 *      Author: Administrator
 */
#include "BirdFather.h"
#include "BirdGrandFather.h"

initer(BirdFather){
	obj->super = newc(mo, BirdGrandFather);
	call(obj->super, BirdGrandFather, initWithName, "Father of class [BirdFather]");
	obj->age = 92;
	obj->name = nil;
	return obj;
}

loader(BirdFather){
	binding(BirdFather, BirdFather*, initWithName, char* name);
	binding(BirdFather, void, fly, xxx);
	binding(BirdFather, void, battleWithEagle, mo father);

	return claz;
}

method(BirdFather, BirdFather*, initWithName, char* name)
{
	obj->name = name;
	return obj;
}

method(BirdFather, void, fly, xxx)
{
	printf("%s: i am %d years old, i can fly!\n", obj->name, obj->age);
}

method(BirdFather, void, battleWithEagle, mo father)
{
	printf("%s: i am battling with an eagle!\n", obj->name);
	printf("[%s] as the receiver of _battleWithEagle, i[%s] execute\n",
			nameof(father), nameof(obj));
	//puts(nameof(obj));
}
