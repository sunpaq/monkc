/*
 * BirdGrandFather.c
 *
 *  Created on: 2014��2��15��
 *      Author: Administrator
 */

#include "BirdGrandFather.h"
#include "AbstractBird.h"

initer(BirdGrandFather){
	obj->super = newc(mo, AbstractBird);
	obj->age = 5000;
	obj->name = nil;
	return obj;
}

loader(BirdGrandFather){
	binding(BirdGrandFather, BirdGrandFather*, initWithName, char* name);
	binding(BirdGrandFather, void, battleWithEagle, xxx);
	binding(BirdGrandFather, void, designIphoneWithSteve, xxx);
	binding(BirdGrandFather, void, gotoMoonWithArmstrong, xxx);
	binding(BirdGrandFather, void, _battleWithEagle, mo child);

	return claz;
}

method(BirdGrandFather, BirdGrandFather*, initWithName, char* name)
{
	obj->name = name;
	return obj;
}

method(BirdGrandFather, void, _battleWithEagle, mo child)
{
	ff(child, battleWithEagle, obj);
}

method(BirdGrandFather, void, battleWithEagle, xxx)
{

}

method(BirdGrandFather, void, designIphoneWithSteve, xxx)
{

}

method(BirdGrandFather, void, gotoMoonWithArmstrong, xxx)
{

}
