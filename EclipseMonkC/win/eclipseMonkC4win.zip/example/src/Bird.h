#ifndef Bird_
#define Bird_
extends(AbstractBird);
monkc(Bird);
	int age;
	char* name;
end(Bird);

method(Bird, Bird*, initWithName, char* name);
method(Bird, void, sayHello, xxx);
//implement _swim
method(Bird, void, swim, xxx);
#endif
