


//string operate
void mc_copy_key(char* const dest, const char* src);
int mc_compare_key(char* const dest, const char* src);