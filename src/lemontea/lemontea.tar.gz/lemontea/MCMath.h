#include "MCContext.h"

#ifndef MCMath_ 
#define MCMath_

monkc(MCMath);
	unsigned tid;
end(MCMath);

method(MCMath, void, bye, xxx);
method(MCMath, int, addInteger2, int a, int b);

#endif