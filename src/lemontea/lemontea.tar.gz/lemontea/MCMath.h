#include "MCContext.h"

#ifndef MCMath_ 
#define MCMath_

class(MCMath);
	unsigned tid;
end(MCMath);

method(MCMath, bye, xxx);
method(MCMath, addInteger2, int a, int b) returns(int sum);

#endif