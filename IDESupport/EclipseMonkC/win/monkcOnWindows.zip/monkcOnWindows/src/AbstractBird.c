/*
 * AbstractBird.c
 *
 *  Created on: 2014��2��15��
 *      Author: Administrator
 */

#include "AbstractBird.h"

initer(AbstractBird){
	return obj;
}

loader(AbstractBird)
{
	binding(AbstractBird, void, _fly, xxx);
	binding(AbstractBird, void, _swim, xxx);
	return claz;
}

method(AbstractBird, void, _fly, void* any)
{
	ff(any, fly, any);
}

method(AbstractBird, void, _swim, void* any)
{
	if(response_to(any, swim).addr){
		ff(any, swim, any);
	}else{
		printf("[%s] can not swim [%s]: i swim\n", nameof(any), nameof(obj));
	}
}
