#include "Bird.h"
#include "BirdFather.h"

initer(Bird)
{
	obj->super = newc(mo, BirdFather);
	call(obj->super, BirdFather, initWithName, "Father of class [Bird]");
	obj->age = 29;
	obj->name = cast(BirdFather*, obj->super)->name;
	return obj;
}

loader(Bird)
{
	binding(Bird, Bird*, initWithName, char* name);
	binding(Bird, void, sayHello, xxx);
	//
	binding(Bird, void, swim, xxx);
	return claz;
}

method(Bird, Bird*, initWithName, char* name)
{
	obj->name = name;
	return obj;
}

method(Bird, void, sayHello, xxx)
{
	//int a = (int)xx;

	printf("%s: i am %d years old, hello!\n", obj->name, obj->age);
	//printf("%d", a);
}

method(Bird, void, swim, xxx)
{
	printf("%s: i swimming\n", nameof(obj));
}
