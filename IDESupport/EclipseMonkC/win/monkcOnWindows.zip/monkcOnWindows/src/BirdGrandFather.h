/*
 * BirdGrandFather.h
 *
 *  Created on: 2014��2��15��
 *      Author: Administrator
 */

#ifndef BIRDGRANDFATHER_H_
#define BIRDGRANDFATHER_H_

monkc(BirdGrandFather);
	int age;
	char* name;
end(BirdGrandFather);

method(BirdGrandFather, BirdGrandFather*, initWithName, char* name);
method(BirdGrandFather, void, _battleWithEagle, mo child);
method(BirdGrandFather, void, battleWithEagle, xxx);
method(BirdGrandFather, void, designIphoneWithSteve, xxx);
method(BirdGrandFather, void, gotoMoonWithArmstrong, xxx);

#endif /* BIRDGRANDFATHER_H_ */
