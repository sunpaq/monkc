#ifndef BirdFather_
#define BirdFather_

monkc(BirdFather);
	int age;
	char* name;
end(BirdFather);

method(BirdFather, BirdFather*, initWithName, char* name);
method(BirdFather, void, fly, xxx);
method(BirdFather, void, battleWithEagle, mo father);
#endif
