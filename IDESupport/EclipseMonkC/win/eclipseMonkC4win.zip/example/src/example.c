/*
 ============================================================================
 Name        : example.c
 Author      : sunyuli
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

//#include <stdio.h>
//#include <stdlib.h>

#include "Bird.h"
#include "BirdFather.h"
#include "MCArray.h"

int main(void) {
	puts("!!!Hello World!!!"); /* prints !!!Hello World!!! */

	char* metname = "a static string";
	char* b = metname;

	printf(b);
	//printf(*getAddr("a static string"));


	//LOG_LEVEL = MC_VERBOSE;
	Bird* abird = ff(new(Bird), initWithName, "a little bird");
	BirdFather* fb = ff(new(BirdFather), initWithName, "father bird");
	ff(abird, sayHello, nil);

	ff(abird, fly, nil);
	ff(abird, _battleWithEagle, abird);

	ff(abird, _swim, abird);
	ff(fb, _swim, fb);

	MCArray* arr = new(MCArray);
	//ff(arr, initWithSize, 10);
	ff(arr, addItem, abird);
	ff(arr, addItem, abird);
	ff(arr, addItem, abird);
	ff(arr, addItem, abird);
	ff(arr, addItem, abird);
	ff(arr, addItem, fb);
	ff(arr, addItem, fb);
	ff(arr, addItem, fb);
	ff(arr, addItem, fb);
	ff(arr, addItem, fb);
	//>10
	//ff(arr, addItem, fb);
	//ff(arr, addItem, fb);

	void visitor(_lamda, void* item, int index) {
		printf("visit a item: - ");
		ff(item, _swim, item);
	} ff(arr, visiteEachBy, lamda(visitor));

	ff(arr, clear, nil);

	void visitor2(_lamda, void* item, int index) {
		printf("visit a item: - \n");
		if(item)ff(item, _swim, item);
	} ff(arr, visiteEachBy, lamda(visitor2));

	ff(abird, abcde6789x123456789x123456789x123456789x123456789x123456789x, nil);

	return EXIT_SUCCESS;
}
