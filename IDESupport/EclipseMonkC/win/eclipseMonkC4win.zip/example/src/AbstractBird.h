/*
 * AbstractBird.h
 *
 *  Created on: 2014��2��15��
 *      Author: Administrator
 */

#ifndef ABSTRACTBIRD_H_
#define ABSTRACTBIRD_H_

monkc(AbstractBird);
	int age;
	char* name;
end(AbstractBird);

method(AbstractBird, void, _fly, xxx);
method(AbstractBird, void, _swim, xxx);


#endif /* ABSTRACTBIRD_H_ */
