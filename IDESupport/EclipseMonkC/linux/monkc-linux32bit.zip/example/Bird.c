/*
 * Bird.c
 *
 *  Created on: 2014-2-11
 *      Author: suntu
 */
#include "Bird.h"
#include "BirdFather.h"

initer(Bird)
{
	obj->super = newc(mo, BirdFather);
	ff(obj->super, initWithName, "Bird's father");
	obj->age = 29;
	obj->name = nil;
	return obj;
}

method(Bird, Bird*, initWithName, char* name)
{
	obj->name = name;
	return obj;
}

method(Bird, void, fly, xxx)
{
	printf("name:%s age:%d fly\n", obj->name, obj->age);
}

//override abstract
method(Bird, int, hello_imp, xxx)
{
	return 1;
}

loader(Bird)
{
	binding(Bird, Bird*, initWithName, char* name);
	binding(Bird, int, hello_imp, xxx);
	//binding(Bird, void, fly, xxx);
	return claz;
}


