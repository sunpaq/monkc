/*
 * BirdGrandFather.c
 *
 *  Created on: 2014-2-11
 *      Author: suntu
 */
#include "BirdGrandFather.h"

initer(BirdGrandFather)
{
	obj->super = nil;
	obj->age = 200;
	obj->name = nil;
	return obj;
}

loader(BirdGrandFather)
{
	binding(BirdGrandFather, BirdGrandFather*, initWithName, char* name);
	binding(BirdGrandFather, void, fly, xxx);
	binding(BirdGrandFather, int, getAge, xxx);
	binding(BirdGrandFather, int, hello_abs, mo receiver);
	return claz;
}

method(BirdGrandFather, BirdGrandFather*, initWithName, char* name)
{
	obj->name = name;
	return obj;
}

method(BirdGrandFather, void, fly, xxx)
{
	printf("name:%s age:%d fly\n", obj->name, obj->age);
}

method(BirdGrandFather, int, getAge, xxx)
{
	return obj->age;
}

//abstract
method(BirdGrandFather, int, hello_abs, mo receiver)
{
	return (int)ff(receiver, hello_imp, nil);
}
