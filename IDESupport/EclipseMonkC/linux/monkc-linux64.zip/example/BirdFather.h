/*
 * BirdFather.h
 *
 *  Created on: 2014-2-11
 *      Author: suntu
 */

#ifndef BIRDFATHER_H_
#define BIRDFATHER_H_

#include "monkc.h"

monkc(BirdFather);
	int age;
	char* name;
end(BirdFather);

method(BirdFather, BirdFather*, initWithName, char* name);
method(BirdFather, int, getAge, xxx);
method(BirdFather, void, fly, xxx);
method(BirdFather, void, battleWithEagle, xxx);
//override abstract
method(BirdFather, int, hello_imp, xxx);
#endif /* BIRDFATHER_H_ */
