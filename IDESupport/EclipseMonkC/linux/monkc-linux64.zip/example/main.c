/*
 * main.c
 *
 *  Created on: 2014-2-11
 *      Author: suntu
 */


#include "monkc.h"
#include "Bird.h"
#include "BirdFather.h"

int main(int argc, char* argv[])
{
	mc_init();

		Bird* abird = ff(new(Bird), initWithName, "little bird");
		ff(abird, fly, nil);
		ff(abird, battleWithEagle, nil);

		BirdFather* father = ff(new(BirdFather), initWithName, "father bird");
		ff(father, fly, nil);

		printf("%s:my hello: %d\n", abird->name, (int)ff(abird, hello_abs, abird));
		printf("%s:my hello: %d\n", father->name, (int)ff(father, hello_abs, father));
	mc_end();
	return 0;
}
