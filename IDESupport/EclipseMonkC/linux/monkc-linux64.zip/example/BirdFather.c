/*
 * BirdFather.c
 *
 *  Created on: 2014-2-11
 *      Author: suntu
 */

#include "monkc.h"
#include "BirdFather.h"
#include "BirdGrandFather.h"

initer(BirdFather)
{
	//no need to put nil super here
	//but it is good to indicate which
	//is the root class
	obj->super = newc(mo, BirdGrandFather);
	obj->age = 59;
	obj->name = nil;
	return obj;
}

method(BirdFather, BirdFather*, initWithName, char* name)
{
	obj->name = name;
	return obj;
}

method(BirdFather, int, getAge, xxx)
{
	return obj->age;
}

method(BirdFather, void, fly, xxx)
{
	//debug_log("father fly\n");
	printf("name:%s age:%d fly\n", obj->name, obj->age);
}

method(BirdFather, void, battleWithEagle, xxx)
{
	//debug_log("i am battling with eagle\n");
	printf("i am battling with eagle\n");
}

//override abstract
method(BirdFather, int, hello_imp, xxx)
{
	return 10;
}

loader(BirdFather)
{
	binding(BirdFather, BirdFather*, initWithName, char* name);
	binding(BirdFather, int, getAge, xxx);
	binding(BirdFather, void, fly, xxx);
	binding(BirdFather, void, battleWithEagle, xxx);
	binding(BirdFather, int, hello_imp, xxx);
	return claz;
}
