/*
 * BirdGrandFather.h
 *
 *  Created on: 2014-2-11
 *      Author: suntu
 */

#ifndef BIRDGRANDFATHER_H_
#define BIRDGRANDFATHER_H_

#include "monkc.h"

monkc(BirdGrandFather);
	int age;
	char* name;
end(BirdGrandFather);

method(BirdGrandFather, BirdGrandFather*, initWithName, char* name);
method(BirdGrandFather, void, fly, xxx);
method(BirdGrandFather, int, getAge, xxx);
//abstract
method(BirdGrandFather, int, hello_abs, mo receiver);

#endif /* BIRDGRANDFATHER_H_ */
