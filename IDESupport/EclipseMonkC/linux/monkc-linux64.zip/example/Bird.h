/*
 * Bird.h
 *
 *  Created on: 2014-2-11
 *      Author: suntu
 */
#include "monkc.h"

#ifndef BIRD_H_
#define BIRD_H_

monkc(Bird);
	int age;
	char* name;
end(Bird);

method(Bird, Bird*, initWithName, char* name);
method(Bird, void, fly, xxx);
//override abstract
method(Bird, int, hello_imp, xxx);
#endif /* BIRD_H_ */
