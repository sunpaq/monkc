
#include "Bird.h"
#include "MCContext.h"

int main(int argc, char* argv[])
{
	char sel;
	Bird* msbird = new(Bird);
	MCContext* ctx = new(MCContext);

	for(;;){
		printf("----------------------\n");
		sel = call(ctx, MCContext, showMenuAndGetSelectionChar, 
		3,
		"let bird fly",
		"let bird swim",
		"let bird sing");

		switch (sel)
		{
			case '1':
				ff(msbird, fly, nil);
				break;
			case '2':
				ff(msbird, swim, nil);
				break;
			case '3':
				ff(msbird, sing, nil);
				break;
			default:
				break;
		}
	}

	return 0;
}