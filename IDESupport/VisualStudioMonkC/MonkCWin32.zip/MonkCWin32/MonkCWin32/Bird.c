#include "Bird.h"

initer(Bird)
{
	obj->age = 29;
	obj->name = "A bird on M$ visual studio!";
	return obj;
}

loader(Bird)
{
	binding(Bird, Bird*, fly, xxx);
	binding(Bird, Bird*, swim, xxx);
	binding(Bird, Bird*, sing, xxx);

	binding(Bird, Bird*, setName, char* name);
	binding(Bird, Bird*, setAge, int age);
	binding(Bird, Bird*, reportName, xxx);
	binding(Bird, Bird*, reportAge, xxx);
	return claz;
}

method(Bird, Bird*, fly, xxx)
{
	debug_log("[%s] i am flying\n", obj->name);
	return obj;
}

method(Bird, Bird*, swim, xxx)
{
	debug_log("[%s] i am swimming\n", obj->name);
	return obj;
}

method(Bird, Bird*, sing, xxx)
{
	debug_log("[%s] i am singing\n", obj->name);
	return obj;
}

method(Bird, Bird*, setName, char* name)
{
	obj->name = name;
	return obj;
}

method(Bird, Bird*, setAge, int age)
{
	obj->age = age;
	return obj;
}

method(Bird, Bird*, reportName, xxx)
{
	debug_log("my name is: %s\n", obj->name);
	return obj;
}

method(Bird, Bird*, reportAge, xxx)
{
	debug_log("my age is: %d\n", obj->age);
	return obj;
}