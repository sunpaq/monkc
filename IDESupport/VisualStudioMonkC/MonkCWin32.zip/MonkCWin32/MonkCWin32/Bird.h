#include "monkc.h"

#ifndef Bird_
#define Bird_

monkc(Bird);
	int age;
	char* name;
end(Bird);

method(Bird, Bird*, fly, xxx);
method(Bird, Bird*, swim, xxx);
method(Bird, Bird*, sing, xxx);

method(Bird, Bird*, setName, char* name);
method(Bird, Bird*, setAge, int age);
method(Bird, Bird*, reportName, xxx);
method(Bird, Bird*, reportAge, xxx);

#endif